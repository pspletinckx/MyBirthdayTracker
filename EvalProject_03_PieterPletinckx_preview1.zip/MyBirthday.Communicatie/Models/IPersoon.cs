﻿namespace MyBirthday.Communicatie.Models
{
    public interface IPersoon
    {
    }
}